/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package trycatch;

import javax.swing.JOptionPane;

/**
 *
 * @author matheus.sribeiro22
 */
public class Trycatch {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        /* TODO code application logic here
        int valor = 5;
        String valor2 = "10";
        int valor3 = 0;
        //System.out.println(valor + valor2);
        //System.out.println(valor/valor3);
        int []numeros ={50,30,40};
        System.out.println(numeros[10]);
        
        
        int valor = 5;
        int valor2 = 0;
        
        try{
            
            int resultado = valor/valor2;
            
            System.out.println(" o resultado é" + resultado);
            
        }catch(ArithmeticException e){
            
            System.out.println("divisao por zero");
            */
        String idadeTexto = JOptionPane.showInputDialog("Digite sua idade (apenas numeros");
        try{
            
            int idade = Integer.parseInt(idadeTexto);
            JOptionPane.showMessageDialog(null, "sua idade é: " + idade + " anos.");
            
        }catch (NumberFormatException e) {
            
            JOptionPane.showMessageDialog(null,
                    "Erro de Formato: Por Favor, digite apenas numeros validos",
                    
                    "Erro de Entrada", JOptionPane.ERROR_MESSAGE);
        }
        System.out.println("Processo de idade finalizado.");
    }
    
}
